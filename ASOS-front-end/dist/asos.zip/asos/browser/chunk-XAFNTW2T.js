import{o as a}from"./chunk-HFJT3PIT.js";import"./chunk-G7D7R4RW.js";import"./chunk-LNHSO6ZX.js";import"./chunk-KAOPS22R.js";export{a as ShoppingCartModule};
